#!/bin/sh

exec "${PACKAGE}" "$@"
