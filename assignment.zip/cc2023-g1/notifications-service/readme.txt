Usage: notifications-service --secret-key <SECRET_KEY> --external-ip <EXTERNAL_IP>

E.g.: cargo run -p notifications-service --bin notifications-service -- \
    --secret-key QJUHsPhnA0eiqHuJqsPgzhDozYO4f1zh \
    --external-ip 127.0.0.1

Options:
  -s, --secret-key <SECRET_KEY>
  -e, --external-ip <EXTERNAL_IP>
  -h, --help                       Print help
